create function getprojectbyuserid(userid integer)
    returns TABLE(id integer, name character varying, description character varying, creation_date timestamp without time zone, deadline timestamp without time zone, creator_id integer, status_id integer)
    language plpgsql
as
$$
begin
    return query
        (select p.id, p.name, p.description, p.creation_date, p.deadline, p.creator_id, p.status_id
         from projects p
                  join project_members pm on p.id = pm.project_id
         where user_id = userId);
end
$$;

alter function getprojectbyuserid(integer) owner to postgres;

