create function gettasksandcheckthemdeadline(projectid integer)
    returns TABLE(assignee_id integer, category_id integer, creator_id integer, id integer, priority integer, project_id integer, status_id integer, deadline timestamp without time zone, start_date timestamp without time zone, update_date timestamp without time zone, description text, title character varying)
    language plpgsql
as
$$
BEGIN
    
    UPDATE tasks
    SET status_id = 5
    WHERE
        tasks.project_id = projectId
      AND now() >= tasks.deadline
      AND tasks.status_id != 5;  

    
    RETURN QUERY
        SELECT
            t.assignee_id,
            t.category_id,
            t.creator_id,
            t.id,
            t.priority,
            t.project_id,
            t.status_id,
            t.deadline,
            t.start_date,
            t.update_date,
            t.description,
            t.title
        FROM tasks t
        WHERE t.project_id = projectId;
END
$$;

alter function gettasksandcheckthemdeadline(integer) owner to postgres;

