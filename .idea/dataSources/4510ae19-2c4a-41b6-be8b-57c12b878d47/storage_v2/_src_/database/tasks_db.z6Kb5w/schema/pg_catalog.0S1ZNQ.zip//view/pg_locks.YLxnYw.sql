create view pg_locks
            (locktype, database, relation, page, tuple, virtualxid, transactionid, classid, objid, objsubid,
             virtualtransaction, pid, mode, granted, fastpath, waitstart)
as
SELECT locktype,
       database,
       relation,
       page,
       tuple,
       virtualxid,
       transactionid,
       classid,
       objid,
       objsubid,
       virtualtransaction,
       pid,
       mode,
       granted,
       fastpath,
       waitstart
FROM pg_lock_status() l(locktype, database, relation, page, tuple, virtualxid, transactionid, classid, objid, objsubid,
                        virtualtransaction, pid, mode, granted, fastpath, waitstart);

alter table pg_locks
    owner to postgres;

grant select on pg_locks to public;

